package com.walhero.neufrevision;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private JSONObject data;
    private LinearLayout root;
    private final int BLUE = Color.rgb(11, 61, 145);
    private final int GOLD = Color.rgb(244, 180, 0);
    private final int BG = Color.rgb(245, 247, 251);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        data = loadJson();
        showHome();
    }

    private JSONObject loadJson() {
        try {
            InputStream is = getAssets().open("exams.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
            reader.close();
            return new JSONObject(builder.toString());
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تحميل بيانات الامتحانات", Toast.LENGTH_LONG).show();
            return new JSONObject();
        }
    }

    private void baseScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void showHome() {
        baseScreen();
        addTitle("طريقك للنوفيام", "السنة التاسعة أساسي");
        addParagraph("تطبيق Android Native تجريبي لمراجعة النوفيام: امتحانات رسمية + إصلاحات + امتحانات مشابهة مولّدة من نفس الكفايات.");
        addSmallNote("هذه النسخة تضم مادة الرياضيات مع نموذج رسمي حقيقي: دورة 2018 من 9web/Edunet، وروابط PDF للاختبار والإصلاح، إضافة إلى اختبار مشابه مولّد مع إصلاحه.");

        try {
            JSONArray subjects = data.getJSONArray("subjects");
            for (int i = 0; i < subjects.length(); i++) {
                JSONObject subject = subjects.getJSONObject(i);
                Button b = makeButton(subject.getString("name"), BLUE);
                final int index = i;
                b.setOnClickListener(v -> showSubject(index));
                root.addView(b);
            }
        } catch (Exception e) {
            addParagraph("لا توجد بيانات مواد حاليا.");
        }
    }

    private void showSubject(int subjectIndex) {
        baseScreen();
        try {
            JSONObject subject = data.getJSONArray("subjects").getJSONObject(subjectIndex);
            addBackButton(() -> showHome());
            addTitle(subject.getString("name"), "اختر السنة");
            JSONArray years = subject.getJSONArray("years");
            if (years.length() == 0) {
                addParagraph("لم تتم إضافة امتحانات هذه المادة بعد. البنية جاهزة، ويمكن إدخال نصوص الامتحانات والإصلاحات في ملف exams.json.");
                return;
            }
            for (int i = 0; i < years.length(); i++) {
                JSONObject year = years.getJSONObject(i);
                Button b = makeButton(String.valueOf(year.getInt("year")), BLUE);
                final int y = i;
                b.setOnClickListener(v -> showYear(subjectIndex, y));
                root.addView(b);
            }
        } catch (Exception e) {
            showHome();
        }
    }

    private void showYear(int subjectIndex, int yearIndex) {
        baseScreen();
        try {
            JSONObject subject = data.getJSONArray("subjects").getJSONObject(subjectIndex);
            JSONObject year = subject.getJSONArray("years").getJSONObject(yearIndex);
            addBackButton(() -> showSubject(subjectIndex));
            addTitle(subject.getString("name") + " - " + year.getInt("year"), "اختر نوع المحتوى");

            Button official = makeButton("الامتحان الرسمي", BLUE);
            official.setOnClickListener(v -> showTextScreen(
                    subjectIndex,
                    yearIndex,
                    year.optString("officialTitle", "الامتحان الرسمي"),
                    year.optString("officialExam", "")
            ));
            root.addView(official);

            Button correction = makeButton("إصلاح الامتحان الرسمي", GOLD);
            correction.setTextColor(Color.rgb(40, 40, 40));
            correction.setOnClickListener(v -> showTextScreen(
                    subjectIndex,
                    yearIndex,
                    "إصلاح الامتحان الرسمي",
                    year.optString("officialCorrection", "")
            ));
            root.addView(correction);

            String officialPdfUrl = year.optString("officialPdfUrl", "");
            if (!officialPdfUrl.isEmpty()) {
                Button openOfficialPdf = makeButton("فتح PDF الاختبار الرسمي", BLUE);
                openOfficialPdf.setOnClickListener(v -> openUrl(officialPdfUrl));
                root.addView(openOfficialPdf);
            }

            String correctionPdfUrl = year.optString("correctionPdfUrl", "");
            if (!correctionPdfUrl.isEmpty()) {
                Button openCorrectionPdf = makeButton("فتح PDF الإصلاح الرسمي", GOLD);
                openCorrectionPdf.setTextColor(Color.rgb(40, 40, 40));
                openCorrectionPdf.setOnClickListener(v -> openUrl(correctionPdfUrl));
                root.addView(openCorrectionPdf);
            }

            Button generated = makeButton("اختبار مشابه مولّد", BLUE);
            generated.setOnClickListener(v -> {
                JSONObject g = year.optJSONObject("generated");
                showTextScreen(subjectIndex, yearIndex, g != null ? g.optString("title", "اختبار مشابه") : "اختبار مشابه", g != null ? g.optString("exam", "") : "");
            });
            root.addView(generated);

            Button genCorrection = makeButton("إصلاح الاختبار المشابه", GOLD);
            genCorrection.setTextColor(Color.rgb(40, 40, 40));
            genCorrection.setOnClickListener(v -> {
                JSONObject g = year.optJSONObject("generated");
                showTextScreen(subjectIndex, yearIndex, "إصلاح الاختبار المشابه", g != null ? g.optString("correction", "") : "");
            });
            root.addView(genCorrection);
        } catch (Exception e) {
            showSubject(subjectIndex);
        }
    }


    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_LONG).show();
        }
    }

    private void showTextScreen(int subjectIndex, int yearIndex, String title, String body) {
        baseScreen();
        addBackButton(() -> showYear(subjectIndex, yearIndex));
        addTitle(title, "");
        addExamText(body == null || body.trim().isEmpty() ? "لا يوجد نص مضاف بعد." : body);
    }

    private void addTitle(String main, String sub) {
        TextView t = new TextView(this);
        t.setText(main);
        t.setTextColor(BLUE);
        t.setTextSize(28);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        root.addView(t, matchWrap());

        if (sub != null && !sub.isEmpty()) {
            TextView s = new TextView(this);
            s.setText(sub);
            s.setTextColor(Color.rgb(80, 80, 80));
            s.setTextSize(17);
            s.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = matchWrap();
            lp.setMargins(0, dp(6), 0, dp(16));
            root.addView(s, lp);
        }
    }

    private void addParagraph(String text) {
        TextView p = new TextView(this);
        p.setText(text);
        p.setTextSize(17);
        p.setTextColor(Color.rgb(45, 45, 45));
        p.setGravity(Gravity.RIGHT);
        p.setLineSpacing(6, 1.05f);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(4), 0, dp(14));
        root.addView(p, lp);
    }

    private void addSmallNote(String text) {
        TextView p = new TextView(this);
        p.setText(text);
        p.setTextSize(14);
        p.setTextColor(Color.rgb(90, 90, 90));
        p.setGravity(Gravity.RIGHT);
        p.setPadding(dp(14), dp(12), dp(14), dp(12));
        p.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(2), 0, dp(18));
        root.addView(p, lp);
    }

    private void addExamText(String text) {
        TextView p = new TextView(this);
        p.setText(text);
        p.setTextSize(18);
        p.setTextColor(Color.rgb(30, 30, 30));
        p.setGravity(Gravity.RIGHT);
        p.setLineSpacing(8, 1.08f);
        p.setPadding(dp(16), dp(16), dp(16), dp(16));
        p.setBackgroundColor(Color.WHITE);
        root.addView(p, matchWrap());
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(color);
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private void addBackButton(final Runnable action) {
        Button back = makeButton("رجوع", Color.rgb(90, 90, 90));
        back.setOnClickListener(v -> action.run());
        root.addView(back);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        showHome();
    }
}
